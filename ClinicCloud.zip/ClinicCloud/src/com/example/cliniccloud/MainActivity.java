package com.example.cliniccloud;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Menu;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.*;
import android.os.Bundle;
import android.webkit.*;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		WebView myWebView = (WebView) this.findViewById(R.id.webView);
		myWebView.getSettings().setJavaScriptEnabled(true);
		myWebView.getSettings().setBuiltInZoomControls(true);
        myWebView.loadUrl("https://cliniccloud.es/app/login.php");
        
        myWebView.setWebViewClient(new WebViewClient(){
            
            public boolean shouldOverrideUrlLoading(WebView view, String url){
                return false;
            }
        });
        
        myWebView.setDownloadListener(new DownloadListener() {
          	 
            public void onDownloadStart(final String url, String userAgent, String contentDisposition, String mimetype, long contentLength){               
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Descarga");
                builder.setMessage("�Desea guardar el fichero en su tarjeta SD?");
                builder.setCancelable(false).setPositiveButton("Aceptar", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id){
                        descargar(url);
                    }
                     
                }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                builder.create().show();                
                 
                 
            }
             
            private void descargar(final String url){
               String resultado ="";
                 
               URL urlObject = null;
               InputStream inputStream = null;
               HttpURLConnection urlConnection = null;
               try{
                    urlObject = new URL(url);
                    urlConnection = (HttpURLConnection) urlObject.openConnection();
                         
                    inputStream = urlConnection.getInputStream();
     
                
                    String fileName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/webviewdemo";
                    File directorio = new File(fileName);
                    File file = new File(directorio, url.substring(url.lastIndexOf("/")));
                    
                    directorio.mkdirs();                    
                     
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
     
                    byte[] buffer = new byte[1024];
                     
                    int len = 0;
                    while (inputStream.available() > 0 && (len = inputStream.read(buffer)) != -1){
                        byteArrayOutputStream.write(buffer, 0, len);
                    }
                    fileOutputStream.write(byteArrayOutputStream.toByteArray());
                    fileOutputStream.flush();
                    resultado = "guardado en : " + file.getAbsolutePath();
                }
                catch (Exception ex){
                    resultado = ex.getClass().getSimpleName() + " " + ex.getMessage();
                }
                finally{
                    if (inputStream != null){
                        try{
                            inputStream.close();
                        }
                        catch (IOException e){
                             
                        }
                    }
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
                 
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage(resultado).setPositiveButton("Aceptar", null).setTitle("Descarga");
                builder.show();
            }
     	 });
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
